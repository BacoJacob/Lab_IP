function lastUpdated() {
  var x = document.lastModified;
  document.getElementById("date").innerHTML = x;
}
